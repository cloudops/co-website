---
title: Case Studies
type: subpage-resources
---

<div class="blog-main subpage-resources">
<div class="hero jumbotron jumbotron-fluid">
        <div class="container-fluid">
            <div class="row">
                <div class="col-xl-5 offset-xl-2 col-lg-7 offset-lg-1 col-md-10 offset-md-1 col-sm-10 offset-sm-1 col-xs-12">
                        <h1 class="display-4">Case Studies</h1>
                </div>
                <div class="hero-image-container col-xl-3 offset-xl-0 col-lg-2 offset-lg-0 col-md-10 offset-md-1 col-sm-10 offset-sm-1 col-xs-12">
                    <img src="/images/resources-landing.svg" width="200px">
                </div>
            </div>
        </div>
        </div>