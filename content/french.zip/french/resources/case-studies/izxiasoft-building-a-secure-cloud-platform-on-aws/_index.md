---
title: Ixiasoft - Building a Secure Cloud Platform on AWS
ExternalLink: https://cdn2.hubspot.net/hubfs/732832/One-pagers/CloudOps_CS_Xiasoft_EN_19-10-29.pdf
resources:
- name: "thumbnail"
  src: "ixiasoft_square.png"
---