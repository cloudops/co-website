---
title: CloudOps and Element AI - Building a Cloud Native Platform on Azure
ExternalLink: https://cdn2.hubspot.net/hubfs/732832/EN_CloudOps_CS_Element-AI_Consulting-Enablement_19-12-17.pdf
resources:
- name: "thumbnail"
  src: "element-ai-square.png"
---