---
title: Hospitality Digital - Cloud Migration to GCP
ExternalLink: https://cdn2.hubspot.net/hubfs/732832/CaseStudy_CloudOps_GCP%20Cloud%20Migration.pdf
resources:
- name: "thumbnail"
  src: "hospitality_digital.png"
---