---
title: How to Migrate your Applications into the Cloud
ExternalLink: https://f.hubspotusercontent30.net/hubfs/732832/Infographics/Infographic%20-%20How%20to%20migrate%20cloud%20native%20applications%20into%20the%20cloud.jpg
resources:
- name: "thumbnail"
  src: "migrate.png"
---
