---
title: Cutting Cost in the Cloud
ExternalLink: https://f.hubspotusercontent30.net/hubfs/732832/Infographics/Infographic%20-%20Cutting%20Costs%20in%20the%20Cloud.pdf
resources:
- name: "thumbnail"
  src: "cutting-costs.png"
---
