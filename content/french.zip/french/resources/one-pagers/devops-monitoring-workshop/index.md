---
title: DevOps Monitoring Workshop
ExternalLink: https://cdn2.hubspot.net/hubfs/732832/One-pagers/CloudOps_1Pager_DevOps-Monitoring_Workshop.pdf
resources:
- name: "thumbnail"
  src: "devops-monitoring.png"
---