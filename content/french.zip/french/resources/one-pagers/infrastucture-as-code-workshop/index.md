---
title: Infrastructure as Code Workshop
ExternalLink: https://cdn2.hubspot.net/hubfs/732832/One-pagers/CloudOps_InfrastructureAsCode_workshop.pdf
resources:
- name: "thumbnail"
  src: "infra-as-code.png"
---