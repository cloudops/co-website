---
title: DevOps Platform and Practices Assessment
ExternalLink: https://cdn2.hubspot.net/hubfs/732832/One-pagers/EN_CloudOps_OP_DevOps%20Platform%20and%20Practices%20Assessment_20-03-18.pdf
resources:
- name: "thumbnail"
  src: "dppa.png"
---