---
title: Docker and Kubernetes Workshop
ExternalLink: https://cdn2.hubspot.net/hubfs/732832/One-pagers/EN-Generic_CloudOps_OP_Docker%20and%20Kubernetes%20Workshop_19-04-03.pdf
resources:
- name: "thumbnail"
  src: "kubernetes.png"
---