---
title: CloudOps Workshops Catalogue
ExternalLink: https://cdn2.hubspot.net/hubfs/732832/EN_CloudOps_OP_Workshop%20Catalogue_02-2020.pdf
resources:
- name: "thumbnail"
  src: "workshops-catalogue.png"
---