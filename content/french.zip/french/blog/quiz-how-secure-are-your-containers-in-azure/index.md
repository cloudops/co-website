---
title: "What We Promise Our Customers"
lastmod: "2019-12-02"
author: "CloudOps"
resources:
- name: "thumbnail"
  src: "Container_Social_1200x627_FR_V3.jpg"
class_name: "blog post"
slug: /quiz-dans-quelle-mesure-vos-conteneurs-sont-ils-securises-dans-azure
---

<p>&nbsp;</p>
<div class="smcx-widget smcx-embed smcx-show smcx-widget-dark"><div class="smcx-iframe-container" style="max-width: 700px; height: 440px;"><iframe width="100%" height="100%" frameborder="0" allowtransparency="true" src="https://www.surveymonkey.com/r/X6J9Q9Q?embedded=1"></iframe></div><div class="smcx-widget-footer smcx-embed-footer">
<a style="font: 12px Helvetica, sans-serif; color: #999; text-decoration: none;" href="https://www.surveymonkey.com"> Create your own user feedback survey </a>

