---
title: "Questionnaire : Êtes-vous une « perle rare » Kubernetes ?"
lastmod: "2019-08-23"
author: "CloudOps"
resources:
- name: "thumbnail"
  src: "Quiz.jpg"
class_name: "blog post"
slug: /questionnaire-etes-vous-une-licorne-kubernetes
---

<p>Testez vos connaissances de Kubernetes en répondant à ce questionnaire et découvrez si oui ou non, vous êtes une «&nbsp;perle rare&nbsp;» !</p>

<div class="smcx-widget smcx-embed smcx-show smcx-widget-dark"><div class="smcx-iframe-container" style="max-width: 700px; height: 465px;"><iframe width="100%" height="100%" frameborder="0" allowtransparency="true" src="https://www.surveymonkey.com/r/PBKW7GH?embedded=1"></iframe></div></div>